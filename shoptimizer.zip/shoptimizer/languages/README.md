# Notice! Do not place your custom translation files here.

You can put translations in your child theme: '/wp-content/themes/your-child-theme/languages/it_IT.mo'.