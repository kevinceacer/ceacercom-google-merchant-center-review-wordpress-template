jQuery(function($){
    var page = 2; // 初始加载第二页
    $('#load-more-products').on('click', function(){
        var data = {
            'action': 'load_more_homepage_products',
            'page': page, // 当前页码
        };

        // 发送 AJAX 请求
        $.post(ajaxurl, data, function(response) {
            if (response) {
                $('#products-container').append(response); // 将新产品添加到容器
                page++; // 页码加 1
            }
        });
    });
});